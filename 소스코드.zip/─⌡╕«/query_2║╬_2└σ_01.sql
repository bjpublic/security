CREATE TABLE supermarket(
    food_no int NULL,
    category char(20) NULL,
    food_name char(30) NULL,
    company char(20) NULL,
    price int NULL
)
