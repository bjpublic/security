INSERT INTO order_record
VALUES (1, 'tom' , 1, 3, '2021-01-01')
go 
INSERT INTO order_record
VALUES (2, 'jerry' , 2, 1, '2021-01-02')
go
INSERT INTO order_record
VALUES (3, 'tom' , 3, 1, '2021-01-02')
go
INSERT INTO order_record
VALUES (4, 'tom' , 3, 2, '2021-01-03')
