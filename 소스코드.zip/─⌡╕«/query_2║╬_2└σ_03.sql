CREATE TABLE order_record
(
    order_no int,
    member_id char(20),
    food_no int,
    buy_count int,
    buy_date datetime
)
