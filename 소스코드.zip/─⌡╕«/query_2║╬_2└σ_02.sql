INSERT INTO supermarket
VALUES (1, '과일', '자몽', '마트', 1500)
go
INSERT INTO supermarket
VALUES (2, '음료수', '망고주스', '편의점', 1000)
go
INSERT INTO supermarket
VALUES (3, '음료수', '식혜', '시장', 1000)
go
INSERT INTO supermarket
VALUES (4, '과자', '머랭쿠키', '카페', 3000)
